var express=require('express');
var mysql=require('mysql');
var db=require('./dbConnection');
var session=require('express-session');
var flash=require('express-flash');

var app=express();

var bp=require('body-parser');
const {stringfy}=require('querystring');
const { error } = require('console');
app.use(bp.json());
app.use(bp.urlencoded({extended:true}));

app.use(flash());
app.use(session({
    secret:'your-strong-and-unique-secret',
    resave:false,
    saveUninitialized:true,
    cookie:{ maxAge:7000 }
}));

app.get('/',function(req,res){
    res.sendFile(__dirname + '/login.html');
});

app.post('/auth',function(req,res){
    
    let username=req.body.username;
    let password=req.body.password;
    console.log("Received login request with username:", username);
    if(username && password){
        db.query('SELECT * FROM login WHERE username = ? AND password = ?', [username, password],function(error, results){
            if(error){
                throw error;
            } 
            if(results.length>0){
                console.log("User authenticated. Setting session.");
                req.session.loggedin=true;
                req.session.username=username;
                res.redirect('/register');
            }
            else{
                console.log("Authentication failed.");
                res.send('Incorrect UserName and/or Password');
            }
            res.end();
        });
    }
    else{
        res.send('Please Enter UserName And Password!');
        res.end();
    }
});

app.get('/register',function(req,res){
    if(req.session.loggedin){
        res.sendFile(__dirname+'/register.html');
    }else{
        res.send('Please Login to View this page..');
    }
});

app.post('/formSubmit',function(req,res){
    //console.log("Received form submit request. Session:", req.session);
    //res.send(req.body.name);
    if(req.session.loggedin){

        var name=req.body.name;
        var date=req.body.date;
        var gender=req.body.gender;
        var cls=req.body.cls;
        var regCode=req.body.regCode;

        var sql=`insert into register(name,date,gender,class,regCode) values("${name}", "${date}", "${gender}", "${cls}", "${regCode}")`;
        db.query(sql,function(err,result){
            if(err){
                throw err;
            }
            console.log('record inserted');
            req.flash('success','Data Added Successfully');
            res.redirect('/register');
        });
    }
    else{
        res.send('Please Login to view this Page');
    }
});

app.get('/logout',function(req,res){
    req.session.destroy((err)=>{
        res.redirect('/');
    });
});

app.listen(5001,()=>{
    console.log("server is running")
});