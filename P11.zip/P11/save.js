var express=require('express');
var mysql=require('mysql');
var db=require('./dbConnnection');
var session=require('express-session');
var flash=require('express-flash');

var app=express();

var bp=require('body-parser');
// const {stringfy}=require('querystring');
// const { error } = require('console');
app.use(bp.json());
app.use(bp.urlencoded({extended:true}));

app.use(flash());
app.use(session({
    secret:'your-strong-key',
    resave:false,
    saveUninitialized:true,
    cookie:{ maxAge:70000 }
}));

app.get('/',function(req,res){
    res.sendFile(__dirname + '/login.html');
});

app.post('/auth',function(req,res){
    
    let username=req.body.username;
    let password=req.body.password;
    if(username && password){
        db.query('SELECT * FROM login WHERE username = ? AND password = ?', [username, password],function(error, results){
            if(error){
                throw error;
            } 
            if(results.length>0){
                req.session.loggedin=true;
                req.session.username=username;
                res.redirect('/register');
            }
            else{
                res.send('Incorrect UserName OR Password');
            }
            res.end();
        });
    }
    else{
        res.send('Please Enter UserName And Password!');
        res.end();
    }
});

app.get('/register',function(req,res){
    if(req.session.loggedin){
        res.sendFile(__dirname+'/register.html');
    }else{
        res.send('Please Login to View this page..');
    }
});

app.post('/formSubmit',function(req,res){
    if(req.session.loggedin){

        var fname=req.body.fname;
        var lname=req.body.lname;
        var address=req.body.address;
        var city=req.body.city;
        var cls=req.body.cls;

        var sql=`insert into register(fname,lname,address,city,class) values("${fname}", "${lname}", "${address}", "${city}", "${cls}")`;
        db.query(sql,function(err,result){
            if(err){
                throw err;
            }
            console.log('record inserted');
            req.flash('success','Data Added Successfully');
            // res.redirect('/register');
        });
    }
    else{
        res.send('Please Login to view this Page');
    }
    res.redirect('/register');
    res.end();
});

app.get('/logout',function(req,res){
    req.session.destroy((err)=>{
        res.redirect('/');
    });
});

app.listen(2000,()=>{
    console.log("server is running")
});